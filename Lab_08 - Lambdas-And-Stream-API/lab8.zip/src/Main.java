import bg.sofia.uni.fmi.mjt.netflix.Content;
import bg.sofia.uni.fmi.mjt.netflix.ContentType;
import bg.sofia.uni.fmi.mjt.netflix.NetflixRecommender;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) throws IOException {


    }
}